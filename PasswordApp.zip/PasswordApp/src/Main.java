import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.Session;
import javax.mail.Transport;
import java.util.Properties;



public class Main extends Application {
    private double initial = 0;
    private double end = 0;
    private double contribution = 0;
    private double rate = 0;
    private int years = 0;
    private String verification = "";
    private String checker = "";
    private String passwordCheck = "";
private Label label = new Label(" ");
private String[] credentials = {"",""};
    public static void main(String[] args) {
	launch(args);
    }


    public void start(Stage primaryStage){
        Font font = new Font("Times New Roman",20);

        Label signUpLabel = new Label("Don't have an account? Sign-Up here.->");
        signUpLabel.setFont(font);

        TextField accountUsername = new TextField();
        accountUsername.setFont(font);
        accountUsername.setPromptText("Username");
        accountUsername.setOnMouseReleased(e->{
            label.setText("");
        });

        PasswordField accountPassword = new PasswordField();
        accountPassword.setFont(font);
        accountPassword.setPromptText("Password");
        accountPassword.setOnMouseReleased(e->{
            label.setText("");
        });


        Button logIn = new Button("Log-In");
        logIn.setFont(font);

        Button signUp = new Button("Sign-Up");
        signUp.setFont(font);


          //Sign-Up Page
        signUp.setOnAction(e-> {
                    TextField username = new TextField();
                    username.setFont(font);
                    username.setPromptText("Username");
                    username.setOnMouseReleased(userE->{
                        label.setText("");
                    });


                    PasswordField password = new PasswordField();
                    password.setFont(font);
                    password.setPromptText("Password");
                password.setOnMouseReleased(checkEv->{
                    label.setText("");
                });



                    PasswordField password2 = new PasswordField();
                    password2.setFont(font);
                    password2.setPromptText("Re-enter Password");
            password2.setOnMouseReleased(checkE->{
                label.setText("");
            });




                    Button button = new Button("Sign-Up");
                    button.setFont(font);


                button.setOnAction(ev -> {
                    if(password.getText().equals(password2.getText())){
                        if(password.getText().equals("") || password2.getText().equals("")){
                            label.setText("Invalid Password");
                            label.setFont(font);
                            passwordCheck = "Invalid Password";
                        }
                        else {
                            passwordCheck = "Valid";
                            credentials[1] = password.getText();
                        }
                    }

                    credentials[0] = username.getText();
                    checker = DataHandler.credentials(credentials,2);
                    if(checker.equals("Username already exists")){
                        label.setText("Username already exists");
                        label.setFont(font);
                    }


                    if(password.getText().equals(password2.getText()) && !passwordCheck.equals("Invalid Password")
                    && !checker.equals("Username already exists")) {


                        TextField verificationCode = new TextField();
                        verificationCode.setFont(font);

                        verificationCode.setPromptText("Enter your email");

                        Button emailButton = new Button("Send");
                        emailButton.setFont(font);
                        emailButton.setOnAction(email -> {

                            TextField submitCode = new TextField();
                            submitCode.setFont(font);
                            Button verify = new Button("Verify");
                            verify.setFont(font);

                            verification = DataHandler.verification(verificationCode.getText());

                            verify.setOnAction(v -> {

                                    if (submitCode.getText().equals(verification)) {





                                        label.setText(DataHandler.credentials(credentials, 0));
                                        label.setFont(font);
                                        if(label.getText().equals("Signed-Up")){
                                            String recipient = verificationCode.getText();
                                            String sender = "investcalcseth@gmail.com";
                                            String host = "smtp.gmail.com";
                                            Properties properties = System.getProperties();
                                            properties.put("mail.smtp.host",host);
                                            properties.put("mail.smtp.port","465");
                                            properties.put("mail.smtp.ssl.enable","true");
                                            properties.put("mail.smtp.auth","true");

                                            Session session = Session.getInstance(properties, new Authenticator() {
                                                @Override
                                                protected PasswordAuthentication getPasswordAuthentication() {
                                                    return new PasswordAuthentication("investcalcseth@gmail.com","azypsgtawmagyzce");
                                                }


                                            });



                                            try{
                                                MimeMessage mimeMessage = new MimeMessage(session);
                                                mimeMessage.setFrom(new InternetAddress(sender));
                                                mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
                                                mimeMessage.setSubject("Successful Account Creation");
                                                mimeMessage.setText("Your email has been successfully verified, and your account is ready for use.");

                                                Transport.send(mimeMessage);


                                            }

                                            catch (MessagingException mailE){
                                                System.out.println(mailE.getMessage());
                                            }
                                        }

                                        VBox vBox = new VBox(label);
                                        Scene scene = new Scene(vBox, 1200, 600);
                                        primaryStage.setScene(scene);
                                        primaryStage.setTitle("Signed-Up");
                                        primaryStage.show();
                                    }
                                    else {
                                        label.setText("Incorrect Code");
                                        label.setFont(font);
                                    }




                            });


                            VBox vBox = new VBox(10, submitCode, verify, label);
                            Scene scene = new Scene(vBox, 1200, 600);
                            primaryStage.setScene(scene);
                            primaryStage.setTitle("Verify");
                            primaryStage.show();

                        });


                        VBox vBox = new VBox(10, verificationCode, emailButton);
                        Scene scene = new Scene(vBox, 1200, 600);
                        primaryStage.setScene(scene);
                        primaryStage.setTitle("Email");
                        primaryStage.show();


                    }

                        if(checker.equals("Username already exists")) {
                            label.setText("Username already exists");
                            label.setFont(font);
                        }

                        if (!password.getText().equals(password2.getText())){
                            label.setText("Passwords do not match");
                            label.setFont(font);
                        }



                });



                    VBox vBox = new VBox(10,username,password,password2,button,label);
                    Scene scene = new Scene(vBox,1200,600);
                    primaryStage.setScene(scene);
                    primaryStage.setTitle("Sign-Up");
                    primaryStage.show();
                });


                //Log-In
                logIn.setOnAction(eve -> {
                    credentials[0] = accountUsername.getText();
                    credentials[1] = accountPassword.getText();
                    label.setText(DataHandler.logInCredentials(credentials));
                    label.setFont(font);

                    if (label.getText().equals("Logged-In")) {

                        TextField textField = new TextField();
                        textField.setFont(font);
                        textField.setPromptText("Initial Investment");


                        TextField textField1 = new TextField();
                        textField1.setFont(font);
                        textField1.setPromptText("Additional Annual Contributions");


                        textField1.setOnMouseReleased(keyEvent -> {
                            initial = Double.parseDouble(textField.getText());
                            textField.setText(String.format("$%,.2f", initial));
                            textField.setEditable(false);
                        });

                        TextField textField2 = new TextField();
                        textField2.setFont(font);
                        textField2.setPromptText("Annual Percentage Return Rate");


                        textField2.setOnMouseReleased(keyEvent -> {
                            contribution = Double.parseDouble(textField1.getText());
                            textField1.setText(String.format("$%,.2f", contribution));
                            textField1.setEditable(false);
                        });

                        TextField textField3 = new TextField();
                        textField3.setFont(font);
                        textField3.setPromptText("Years For Investment To Grow");


                        textField3.setOnMouseReleased(keyEvent -> {
                            rate = Double.parseDouble(textField2.getText());
                            textField2.setText(String.format("%.2f%%", rate));
                            textField2.setEditable(false);
                        });

                        TextField textField4 = new TextField();
                        textField4.setFont(font);
                        textField4.setPromptText("Value at Maturity");
                        textField4.setOnKeyPressed(event -> {
                            if (event.getCode() == KeyCode.BACK_SPACE) {
                                textField.setText("");
                                textField.setEditable(true);
                                textField1.setText("");
                                textField1.setEditable(true);
                                textField2.setText("");
                                textField2.setEditable(true);
                                textField3.setText("");
                                textField3.setEditable(true);
                                textField4.setText("");
                            }
                        });

                        textField3.setOnKeyPressed(event -> {


                            if (event.getCode() == KeyCode.ENTER) {

                                years = Integer.parseInt(textField3.getText());
                                end = initial;
                                double actualRate = rate / 100;
                                double temp = 0;

                                for (int index = 0; index < years; index++) {
                                    temp = (initial) * (actualRate + 1);
                                    initial = temp + contribution;
                                }


                                textField3.setText(String.format("%d years", years));
                                textField4.setText(String.format("$%,.2f", initial));
                                initial = end;
                                textField.setEditable(false);
                                textField1.setEditable(false);
                                textField2.setEditable(false);
                                textField3.setEditable(false);
                            }
                        });
                        Button signOut = new Button("Sign-Out");
                        signOut.setFont(font);
                        signOut.setOnAction(signOutEvent -> {
                            label.setText("Signed-out successfully!");
                            VBox vbox = new VBox(label);
                            Scene scene = new Scene(vbox, 1200, 600);
                            primaryStage.setScene(scene);
                            primaryStage.setTitle("Signed-Out");
                            primaryStage.show();
                        });

                        Button calculate = new Button("Calculate");
                        calculate.setFont(font);
                        calculate.setOnAction(calculateAction -> {

                            textField.setEditable(false);
                            textField1.setEditable(false);
                            textField2.setEditable(false);
                            textField3.setEditable(false);
                            years = Integer.parseInt(textField3.getText());
                            end = initial;
                            double actualRate = rate / 100;
                            double temp = 0;

                            for (int index = 0; index < years; index++) {
                                temp = (initial) * (actualRate + 1);
                                initial = temp + contribution;
                            }


                            textField3.setText(String.format("%d years", years));
                            textField4.setText(String.format("$%,.2f", initial));
                            initial = end;


                        });

                        Button reset = new Button("Reset");
                        reset.setFont(font);

                        reset.setOnAction(e -> {
                            textField.setText("");
                            textField.setEditable(true);
                            textField1.setText("");
                            textField1.setEditable(true);
                            textField2.setText("");
                            textField2.setEditable(true);
                            textField3.setText("");
                            textField3.setEditable(true);
                            textField4.setText("");

                        });


                        label.setText("Investment Calculator");
                        label.setFont(font);
                        label.setAlignment(Pos.TOP_CENTER);
                        HBox hBox = new HBox(10, calculate, reset);
                        VBox vBox = new VBox(10, label, textField, textField1, textField2, textField3, textField4, hBox, signOut);
                        Scene scene = new Scene(vBox, 1200, 600);
                        primaryStage.setScene(scene);
                        primaryStage.setTitle("Investment Calculator");
                        primaryStage.show();
                    }

                });


                HBox hbox = new HBox(8, signUpLabel, signUp);
                VBox vbox = new VBox(12, accountUsername, accountPassword, logIn, hbox, label);

                Scene scene = new Scene(vbox, 1200, 600);

                primaryStage.setScene(scene);
                primaryStage.setTitle("Log-In");
                primaryStage.show();




        }
    }




