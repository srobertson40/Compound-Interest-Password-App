

import javax.mail.*;
import javax.mail.internet.*;
import javax.mail.Session;
import javax.mail.Transport;
import java.io.*;
import java.util.Arrays;
import java.util.Properties;
import java.util.Random;
import java.util.Scanner;

public class DataHandler {

   public static String credentials(String[] data, int check) {
       File file = new File(data[0] + ".txt");
       if (check == 2 && file.exists()) {
           return "Username already exists";
       }
       else {

           if (check == 0 && !data[1].equals("")) {
               try (PrintWriter output = new PrintWriter(file)) {
                   output.println(Arrays.toString(data));
                   return "Signed-Up";
               }
               catch (IOException e) {
                   return (e.getMessage());
               }
           }

           if(check == 1){
               if(file.delete()){
                   return "Could not verify";
               }
           }
           return "";


       }
   }

   public static String verification(String from){
       Random random = new Random();
       String randomString = random.ints(48,123)
               .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
               .limit(5)
               .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
               .toString();

       String recipient = from;
       String sender = "investcalcseth@gmail.com";
       String host = "smtp.gmail.com";
       Properties properties = System.getProperties();
       properties.put("mail.smtp.host",host);
       properties.put("mail.smtp.port","465");
       properties.put("mail.smtp.ssl.enable","true");
       properties.put("mail.smtp.auth","true");

       Session session = Session.getInstance(properties, new Authenticator() {
           @Override
           protected PasswordAuthentication getPasswordAuthentication() {
               return new PasswordAuthentication("investcalcseth@gmail.com","azypsgtawmagyzce");
           }


       });



       try{
           MimeMessage mimeMessage = new MimeMessage(session);
           mimeMessage.setFrom(new InternetAddress(sender));
           mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
           mimeMessage.setSubject("Verification");
           mimeMessage.setText("Your verification code is: "+randomString);

           Transport.send(mimeMessage);

       }

       catch (MessagingException e){
           System.out.println(e.getMessage());
       }

       return randomString;




   }

    public static String logInCredentials(String[] data){
       String logIn = "";
       String username = "";
       String password = "";
       File file = new File(data[0]+".txt");

       try(Scanner inputFile = new Scanner(file)){


           while(inputFile.hasNext()){
               logIn += inputFile.next();
           }
           int index = logIn.indexOf("[") + 1;
           int index2 = logIn.indexOf(",");
           int index3 = logIn.indexOf("]");
           username = logIn.substring(index,index2);
           password = logIn.substring(index2 + 1, index3);

           if(data[0].equals(username)){
               if(data[1].equals(password)){
                   return "Logged-In";
               }
               else{
                   return "Incorrect Password";
               }
           }

           else{
            return "Username does not exist";
           }

       }
       catch (FileNotFoundException fileNotFoundException){
           return "Username does not exist";
       }



    }


}

